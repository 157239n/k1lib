# Nucleo free sample
This set includes 100 Nucleo icons (x3 styles, x6 grid sizes). 

The Nucleo icon family includes 30000+ icons.
https://nucleoapp.com/


## License
https://nucleoapp.com/license